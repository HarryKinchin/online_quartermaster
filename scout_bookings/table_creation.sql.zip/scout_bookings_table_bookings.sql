
-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `booking_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `event_name` varchar(50) NOT NULL,
  `event_start` date NOT NULL,
  `event_end` date NOT NULL,
  `collection_date` date NOT NULL,
  `return_date` date NOT NULL,
  `booking_status_id` int(11) NOT NULL DEFAULT '6',
  `approved_by_user_id` int(11) DEFAULT NULL,
  `approval_datetime` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `last_updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
