
-- --------------------------------------------------------

--
-- Table structure for table `item_maintenance_log`
--

CREATE TABLE `item_maintenance_log` (
  `log_id` int(11) NOT NULL,
  `item_code` varchar(10) NOT NULL,
  `log_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `action_type` varchar(50) NOT NULL,
  `description` text,
  `cost_in_gbp` decimal(10,2) DEFAULT NULL,
  `performed_by_user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
