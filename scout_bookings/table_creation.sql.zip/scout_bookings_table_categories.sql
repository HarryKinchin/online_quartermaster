
-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_code` varchar(20) NOT NULL,
  `category_name` varchar(50) NOT NULL,
  `category_description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
