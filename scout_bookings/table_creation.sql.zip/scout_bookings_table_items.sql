
-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `item_code` varchar(50) NOT NULL,
  `category_code` varchar(20) NOT NULL,
  `item_type` varchar(50) NOT NULL,
  `item_name` varchar(50) DEFAULT NULL,
  `item_desc` text COMMENT 'desc of item contents',
  `image_1` varchar(255) DEFAULT NULL,
  `image_2` varchar(255) DEFAULT NULL,
  `image_3` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
