
-- --------------------------------------------------------

--
-- Table structure for table `booking_items`
--

CREATE TABLE `booking_items` (
  `booking_id` int(11) NOT NULL,
  `item_code` varchar(10) NOT NULL,
  `quantity_needed` int(11) NOT NULL,
  `quantity_returned` int(11) DEFAULT NULL,
  `damage_notes_on_return` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
