
-- --------------------------------------------------------

--
-- Table structure for table `components`
--

CREATE TABLE `components` (
  `component_code` varchar(10) NOT NULL,
  `item_code` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL COMMENT 'quantity of components per item unit',
  `item_quality` varchar(255) NOT NULL,
  `quality_desc` text COMMENT 'desc of any damage',
  `return_note` text,
  `replacement_cost` decimal(10,2) DEFAULT NULL,
  `date_purchased` date DEFAULT NULL,
  `end_of_life` date DEFAULT NULL,
  `item_location_code` varchar(50) NOT NULL COMMENT 'location where the specific unit is stored'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
