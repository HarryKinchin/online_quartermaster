
-- --------------------------------------------------------

--
-- Table structure for table `booking_statuses`
--

CREATE TABLE `booking_statuses` (
  `status_id` int(11) NOT NULL,
  `status_name` varchar(50) NOT NULL COMMENT 'Pending, Approved, Collected, Returned, Cancelled'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
