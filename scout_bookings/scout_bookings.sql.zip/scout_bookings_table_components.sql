
-- --------------------------------------------------------

--
-- Table structure for table `components`
--

CREATE TABLE `components` (
  `component_code` varchar(10) NOT NULL,
  `item_code` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL COMMENT 'quantity of components per item unit',
  `item_quality` varchar(255) NOT NULL,
  `quality_desc` text COMMENT 'desc of any damage',
  `return_note` text,
  `replacement_cost` decimal(10,2) DEFAULT NULL,
  `date_purchased` date DEFAULT NULL,
  `end_of_life` date DEFAULT NULL,
  `item_location_code` varchar(50) NOT NULL COMMENT 'location where the specific unit is stored'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `components`
--

INSERT INTO `components` (`component_code`, `item_code`, `quantity`, `item_quality`, `quality_desc`, `return_note`, `replacement_cost`, `date_purchased`, `end_of_life`, `item_location_code`) VALUES
('ICELANDIC1', 'icelandicTent', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS5'),
('ICELANDIC2', 'icelandicTent', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS5'),
('ICELANDIC3', 'icelandicTent', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS5'),
('ICELANDIC4', 'icelandicTent', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS5'),
('SteelPegs1', 'steelPegs', 10, '1', 'Good', NULL, NULL, NULL, NULL, 'IU'),
('SteelPegs2', 'steelPegs', 2, '0', 'Missing some pegs', NULL, NULL, NULL, NULL, 'OOS4'),
('SteelPegs3', 'steelPegs', 20, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS4'),
('TENT001', 'actionPro6', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS4'),
('TENT002', 'actionPro6', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS4'),
('TENT003', 'colemanOct8', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS4'),
('TENT004', 'colemanOct8', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS4'),
('TENT005', 'northgear4', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS4'),
('TENT006', 'northgear4', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS4'),
('TENT007', 'northgear4', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS4'),
('TENT008', 'northgear4', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS4'),
('TENT009', 'northgear4', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS4'),
('TENT010', 'northgear4', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS4'),
('TENT011', 'vangoAlpha400', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS4'),
('TENT012', 'vangoAlpha400', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS4'),
('TENT013', 'vangoAlpha400', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS4'),
('TENT014', 'vangoLomond500', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS4'),
('TENT015', 'vangoLomond500', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS4'),
('TENT016', 'vangoLomond500', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS4'),
('TENT017', 'vangoLomond500', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS4'),
('TENT018', 'vangoLomond500', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS4'),
('TENT019', 'vangoLomond500', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS4'),
('TENT020', 'vangoLomond500', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS4'),
('TENT021', 'vangoLomond500', 1, '1', 'Good', NULL, NULL, NULL, NULL, 'OOS4');
