
-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE `sections` (
  `group_weight` int(11) NOT NULL,
  `group_type` varchar(100) NOT NULL,
  `group_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`group_weight`, `group_type`, `group_name`) VALUES
(1, 'Beavers', 'Churchill'),
(1, 'Beavers', 'Montgomery'),
(1, 'Beavers', 'Mountbatten'),
(2, 'Cubs', 'Cogges'),
(2, 'Cubs', 'Kipling'),
(2, 'Cubs', 'Madley'),
(2, 'Cubs', 'Marlborough'),
(2, 'Cubs', 'Rudyard'),
(4, 'Explorers', 'WESU'),
(5, 'Network', ''),
(5, 'Personal Use', ''),
(3, 'Scouts', 'Bronze Barrow'),
(3, 'Scouts', 'Charles Early'),
(3, 'Scouts', 'Langel'),
(3, 'Scouts', 'Windrush'),
(0, 'Squirrels', 'Nelson');
