
-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_code` varchar(20) NOT NULL,
  `category_name` varchar(50) NOT NULL,
  `category_description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_code`, `category_name`, `category_description`) VALUES
('canvas', 'Canvas Tentage', 'Traditional tents and dining shelters.'),
('cleaning', 'Cleaning Products', 'For tidying up'),
('cookers', 'Fire & Gas Cooking', 'Altar Fires, gas stoves, trangias'),
('cooking', 'Cooking & Food Prep', 'Everything we need to prepare and cook food.'),
('eating', 'Eating Kit', 'Plates and cutlery'),
('lighting', 'Lighting Kit', 'Lighting gear'),
('marquees', 'Marquees', 'Marquees and components'),
('safety', 'Safety Kit', 'First Aid, Barriers, Alarms'),
('tablechair', 'Tables & Chairs', 'All kinds of sitting stuff!'),
('tents', 'Lightweight Tentage', 'Modern tents'),
('toilets', 'Toilets', 'Porta Potties and Toilet Seats'),
('water', 'Water Carriers', 'Fresh, clean water'),
('watercleaning', 'Water Cleaning', NULL);
