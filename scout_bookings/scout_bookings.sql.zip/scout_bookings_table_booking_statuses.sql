
-- --------------------------------------------------------

--
-- Table structure for table `booking_statuses`
--

CREATE TABLE `booking_statuses` (
  `status_id` int(11) NOT NULL,
  `status_name` varchar(50) NOT NULL COMMENT 'Pending, Approved, Collected, Returned, Cancelled'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `booking_statuses`
--

INSERT INTO `booking_statuses` (`status_id`, `status_name`) VALUES
(2, 'Approved'),
(6, 'awaiting_items'),
(5, 'Cancelled'),
(3, 'Collected'),
(1, 'Pending'),
(4, 'Returned');
