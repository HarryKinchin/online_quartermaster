
--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `password_hash`, `first_name`, `last_name`, `email`, `group_type`, `group_name`, `role_id`, `creation_date`) VALUES
(2, '$2y$10$VWm0jLcr25nP.uyF6c8fHeiyc2rXIuGQALQytLxBG6ZqomsK3TzmO', 'Harry', 'Kinchin', 'h.j.kinchin@gmail.com', NULL, NULL, 1, '2025-09-23 14:25:32');
