
--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`booking_id`, `user_id`, `event_name`, `event_start`, `event_end`, `collection_date`, `return_date`, `booking_status_id`, `approved_by_user_id`, `approval_datetime`, `created_at`, `last_updated_at`) VALUES
(8, 2, 'Test camp', '4567-03-12', '7654-08-09', '2583-07-14', '3852-06-09', 6, NULL, NULL, '2025-10-06 11:44:29', '2025-10-06 11:44:29');
