
--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`location_code`, `location_name`) VALUES
('BSS', 'Blake School Shed'),
('IU', 'In Use'),
('MHC', 'Madley Park Hall Cupboard'),
('OOS1', 'Old Oak Stable 1'),
('OOS10', 'Old Oak Stable 10'),
('OOS11', 'Old Oak Stable 11'),
('OOS12', 'Old Oak Stable 12'),
('OOS2', 'Old Oak Stable 2'),
('OOS3', 'Old Oak Stable 3'),
('OOS4', 'Old Oak Stable 4'),
('OOS5', 'Old Oak Stable 5'),
('OOS6', 'Old Oak Stable 6'),
('OOS7', 'Old Oak Stable 7'),
('OOS8', 'Old Oak Stable 8'),
('OOS9', 'Old Oak Stable 9'),
('SH', 'Scout Hut'),
('WODSC', 'West Oxfordshire District Sailing Club');
