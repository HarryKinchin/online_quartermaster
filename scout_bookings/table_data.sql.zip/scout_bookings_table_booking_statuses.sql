
--
-- Dumping data for table `booking_statuses`
--

INSERT INTO `booking_statuses` (`status_id`, `status_name`) VALUES
(2, 'Approved'),
(6, 'awaiting_items'),
(5, 'Cancelled'),
(3, 'Collected'),
(1, 'Pending'),
(4, 'Returned');
