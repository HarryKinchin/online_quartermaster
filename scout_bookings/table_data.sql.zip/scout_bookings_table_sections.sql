
--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`group_type`, `group_name`) VALUES
('Beavers', 'Churchill'),
('Beavers', 'Montgomery'),
('Beavers', 'Mountbatten'),
('Cubs', 'Cogges'),
('Cubs', 'Kipling'),
('Cubs', 'Madley'),
('Cubs', 'Marlborough'),
('Cubs', 'Rudyard'),
('Explorers', 'WESU'),
('Scouts', 'Bronze Barrow'),
('Scouts', 'Charles Early'),
('Scouts', 'Langel'),
('Scouts', 'Windrush'),
('Squirrels', 'Nelson');
