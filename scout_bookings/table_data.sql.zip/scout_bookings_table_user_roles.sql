
--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`role_id`, `role_name`) VALUES
(1, 'Admin'),
(4, 'Group Helper'),
(3, 'Group Leader'),
(2, 'Quarter Master');
